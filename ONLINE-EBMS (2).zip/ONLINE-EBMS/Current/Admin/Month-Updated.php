<?php 
require_once '../../Config.php';
require_once 'Admin-Header.php';
?>

<div class="container h-100" style="padding-top: 140px;">
<div class="row h-100 align-items-center justify-content-center">
<div class="col-lg-6">
<div class="card border-dark shadow-lg">


    <div class="card-body">
        <h2>Month Updated!</h2><br>
        <p class="align-items-center text-center">Month Updated Successfully!</p>
        <div class="align-items-center text-center">
        <a href="Admin-Dashboard.php"><button class="btn btn-danger">OK</button></a>
        </div>
        
    </div>
    </div>

</div>

</div>

</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php
require_once 'Admin-Footer.php';
?>
<?php 
require_once '../../Config.php';
require_once 'User-Header.php';
?>

<div class="container h-100" style="padding-top: 140px;">
<div class="row h-100 align-items-center justify-content-center">
<div class="col-lg-6">
<div class="card border-dark shadow-lg">


    <div class="card-body">
        <h2>Successfully Uploaded!</h2><br>
        <p class="align-items-center text-center">You have succesfully uploaded the form! Please wait until it get approved from Administrators. It may take few hours to get approved.</p>
        <div class="align-items-center text-center">
        <a href="User-Dashboard.php"><button class="btn btn-danger">OK</button></a>
        </div>
        
    </div>
    </div>

</div>

</div>

</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php
require_once 'User-Footer.php';
?>